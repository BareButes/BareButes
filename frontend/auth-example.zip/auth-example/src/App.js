
import React, { Component } from 'react';
import './App.css';
import AuthExample from './AuthExample';

class App extends Component {
  render() {
    return (
      <AuthExample />
    );
  }
}

export default App;